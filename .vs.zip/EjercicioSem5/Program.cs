﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioSem5
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Ingrese un numero decimal: ");
                double num = double.Parse(Console.ReadLine());

            Console.WriteLine($"\nRaiz cuadrada: {Math.Sqrt(num)}");
            Console.WriteLine($"\nRedondeado: {Math.Round(num, 0)}");
            Console.WriteLine($"\nElevado al cubo: {Math.Pow(num, 3)}");
            Console.WriteLine($"\nRaiz cubica: {Math.Pow(num, 1/3d)}");
        }
    }
}
