import math 
num = float(input("Ingrese un numero decimal: "));

print(f"\nRaiz cuadrada: {math.sqrt(num)}");
print(f"\nRedondeado: {round(num, 0)}");
print(f"\nElevado al cubo: {pow(num, 3)}");
print(f"\nRaiz cubica: {num ** (1/3)}");
