﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese un numero: ");
            string num = Console.ReadLine();                               

            double deci = double.Parse(num);
            int entero = (int)Math.Round(deci, 0);

            Console.WriteLine($"\nEntero %2: {entero % 2}");
            Console.WriteLine($"Decimal /3: {deci / 3}");


        }
    }
}
